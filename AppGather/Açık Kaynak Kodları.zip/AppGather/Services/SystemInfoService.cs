using System;
using System.ComponentModel;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using AppGather.Models;

namespace AppGather.Services;

public static class SystemInfoService
{
    private static readonly object ProcessSampleLock = new();
    private static readonly Dictionary<int, (TimeSpan Cpu, DateTime Timestamp)> PreviousProcessSamples = new();

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private sealed class MemoryStatus
    {
        public uint Length = (uint)Marshal.SizeOf<MemoryStatus>();
        public uint MemoryLoad;
        public ulong TotalPhysicalMemory;
        public ulong AvailablePhysicalMemory;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MemoryStatus status);

    public static SystemInfoSnapshot GetSnapshot()
    {
        var memory = GetMemoryText();
        var systemDrive = GetSystemDriveText();

        return new SystemInfoSnapshot
        {
            OperatingSystem = GetWindowsVersionText(),
            Architecture = Environment.Is64BitOperatingSystem ? "64 bit" : "32 bit",
            MachineName = Environment.MachineName,
            UserName = Environment.UserName,
            AdminStatus = AdminHelper.IsAdministrator() ? "Evet" : "Hayır",
            Processor = $"{Environment.ProcessorCount} mantıksal çekirdek",
            Memory = memory,
            SystemDrive = systemDrive,
            TemporaryFiles = $"{FormatBytes((ulong)Math.Max(0, CleanupService.GetTemporaryFilesSize()))} temizlenebilir"
        };
    }

    public static IReadOnlyList<ProcessInfoItem> GetProcessSnapshot()
    {
        var now = DateTime.UtcNow;
        var result = new List<ProcessInfoItem>();
        var currentIds = new HashSet<int>();

        foreach (var process in Process.GetProcesses())
        {
            using (process)
            {
                try
                {
                    currentIds.Add(process.Id);
                    var cpu = process.TotalProcessorTime;
                    var cpuPercent = 0d;
                    lock (ProcessSampleLock)
                    {
                        if (PreviousProcessSamples.TryGetValue(process.Id, out var previous))
                        {
                            var elapsed = (now - previous.Timestamp).TotalMilliseconds * Environment.ProcessorCount;
                            if (elapsed > 0)
                                cpuPercent = Math.Clamp((cpu - previous.Cpu).TotalMilliseconds / elapsed * 100d, 0d, 100d);
                        }
                        PreviousProcessSamples[process.Id] = (cpu, now);
                    }

                    var path = "Erişim yok";
                    try { path = process.MainModule?.FileName ?? "Erişim yok"; }
                    catch (Win32Exception) { }
                    catch (InvalidOperationException) { }

                    result.Add(new ProcessInfoItem
                    {
                        ProcessId = process.Id,
                        Name = process.ProcessName,
                        FilePath = path,
                        CpuPercent = cpuPercent,
                        MemoryBytes = process.WorkingSet64,
                        Status = "Çalışıyor"
                    });
                }
                catch (ArgumentException) { }
                catch (InvalidOperationException) { }
                catch (Win32Exception) { }
                catch (NotSupportedException) { }
            }
        }

        lock (ProcessSampleLock)
        {
            foreach (var id in PreviousProcessSamples.Keys.Where(id => !currentIds.Contains(id)).ToList())
                PreviousProcessSamples.Remove(id);
        }

        return result.OrderByDescending(item => item.CpuPercent).ThenByDescending(item => item.MemoryBytes).ToList();
    }

    private static string GetWindowsVersionText()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            var product = key?.GetValue("ProductName") as string ?? "Windows";
            // Windows 11 çekirdeği geriye dönük uyumluluk nedeniyle 10.0 dönebilir.
            // CurrentBuildNumber, Windows'un yayımladığı gerçek build değeridir.
            var build = key?.GetValue("CurrentBuildNumber")?.ToString() ?? "bilinmiyor";
            var ubr = key?.GetValue("UBR")?.ToString();
            if (int.TryParse(build, out var buildNumber) && buildNumber >= 22000)
                product = product.Replace("Windows 10", "Windows 11", StringComparison.OrdinalIgnoreCase);

            var displayVersion = key?.GetValue("DisplayVersion") as string ?? key?.GetValue("ReleaseId") as string;
            var version = string.IsNullOrWhiteSpace(displayVersion) ? string.Empty : $" {displayVersion}";
            var revision = string.IsNullOrWhiteSpace(ubr) ? string.Empty : $".{ubr}";
            return $"{product}{version} (Build {build}{revision})";
        }
        catch (Exception) { return "Windows sürümü (build bilgisi okunamadı)"; }
    }

    private static string GetMemoryText()
    {
        try
        {
            var status = new MemoryStatus();
            if (!GlobalMemoryStatusEx(status) || status.TotalPhysicalMemory == 0)
            {
                return "Doğrulanamıyor";
            }

            var used = status.TotalPhysicalMemory - Math.Min(status.TotalPhysicalMemory, status.AvailablePhysicalMemory);
            return $"Kullanılan {FormatBytes(used)} / {FormatBytes(status.TotalPhysicalMemory)} toplam · {FormatBytes(status.AvailablePhysicalMemory)} boş";
        }
        catch (Exception)
        {
            return "Doğrulanamıyor";
        }
    }

    private static string GetSystemDriveText()
    {
        try
        {
            var drive = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\");
            return drive.IsReady
                ? $"{FormatBytes((ulong)drive.AvailableFreeSpace)} boş / {FormatBytes((ulong)drive.TotalSize)} toplam"
                : "Doğrulanamıyor";
        }
        catch
        {
            return "Doğrulanamıyor";
        }
    }

    private static string FormatBytes(ulong bytes)
    {
        if (bytes < 1024)
        {
            return $"{bytes} B";
        }

        var value = bytes;
        var units = new[] { "KB", "MB", "GB", "TB" };
        var unitIndex = -1;
        double size = bytes;
        while (size >= 1024 && unitIndex < units.Length - 1)
        {
            size /= 1024;
            unitIndex++;
        }

        return $"{size:0.##} {units[unitIndex]}";
    }
}
