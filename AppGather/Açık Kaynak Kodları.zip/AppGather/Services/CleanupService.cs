using System;
using System.IO;
using System.Threading.Tasks;

namespace AppGather.Services;

public static class CleanupService
{
    public static long GetTemporaryFilesSize()
    {
        return GetDirectorySize(Path.GetTempPath());
    }

    public static async Task<int> CleanTemporaryFilesAsync()
    {
        return await Task.Run(() =>
        {
            var deleted = 0;
            var tempPath = Path.GetTempPath();
            if (!Directory.Exists(tempPath))
            {
                return deleted;
            }

            foreach (var file in Directory.EnumerateFiles(tempPath, "*", SearchOption.TopDirectoryOnly))
            {
                try
                {
                    File.Delete(file);
                    deleted++;
                }
                catch (IOException)
                {
                }
                catch (UnauthorizedAccessException)
                {
                }
            }

            foreach (var directory in Directory.EnumerateDirectories(tempPath))
            {
                try
                {
                    Directory.Delete(directory, recursive: true);
                    deleted++;
                }
                catch (IOException)
                {
                }
                catch (UnauthorizedAccessException)
                {
                }
            }

            LogService.Log($"Geçici dosya temizliği tamamlandı. {deleted} öğe işlendi.", "SUCCESS");
            return deleted;
        });
    }

    private static long GetDirectorySize(string path)
    {
        long total = 0;
        if (!Directory.Exists(path))
        {
            return total;
        }

        try
        {
            foreach (var file in Directory.EnumerateFiles(path, "*", SearchOption.TopDirectoryOnly))
            {
                try
                {
                    total += new FileInfo(file).Length;
                }
                catch (IOException)
                {
                }
                catch (UnauthorizedAccessException)
                {
                }
            }
        }
        catch (IOException)
        {
        }
        catch (UnauthorizedAccessException)
        {
        }

        return total;
    }
}
