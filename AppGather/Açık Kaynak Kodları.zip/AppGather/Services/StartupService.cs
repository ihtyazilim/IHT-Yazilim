using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using Microsoft.Win32;
using AppGather.Models;

namespace AppGather.Services;

public static class StartupService
{
    private const string RunPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";

    public static ObservableCollection<StartupItem> GetItems()
    {
        var items = new ObservableCollection<StartupItem>();
        ReadKey(Registry.CurrentUser, RunPath, "Kullanıcı", items);
        ReadKey(Registry.LocalMachine, RunPath, "Bilgisayar", items);
        return items;
    }

    public static bool Remove(StartupItem item)
    {
        try
        {
            using var baseKey = item.Location == "Kullanıcı" ? Registry.CurrentUser : Registry.LocalMachine;
            using var key = baseKey.OpenSubKey(RunPath, writable: true);
            key?.DeleteValue(item.Name, throwOnMissingValue: false);
            LogService.Log($"Başlangıç girdisi kaldırıldı: {item.Name}", "SUCCESS");
            return true;
        }
        catch (Exception exception)
        {
            LogService.Log($"Başlangıç girdisi kaldırılamadı: {exception.Message}", "ERROR");
            return false;
        }
    }

    private static void ReadKey(RegistryKey hive, string path, string location, ICollection<StartupItem> items)
    {
        try
        {
            using var key = hive.OpenSubKey(path);
            if (key is null)
            {
                return;
            }

            foreach (var name in key.GetValueNames())
            {
                items.Add(new StartupItem
                {
                    Name = name,
                    Command = key.GetValue(name)?.ToString() ?? string.Empty,
                    Location = location,
                    RegistryPath = path
                });
            }
        }
        catch (Exception exception)
        {
            LogService.Log($"Başlangıç girdileri okunamadı: {exception.Message}", "WARN");
        }
    }
}
