using System;
using System.IO;
using System.Windows;
using System.Windows.Media;

namespace AppGather.Services;

public enum ThemeType
{
    Dark,
    Light,
    System,
    Auto
}

public static class ThemeService
{
    private static readonly string ThemeFile = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "AppGather",
        "theme.txt");

    private static ThemeType _currentTheme;
    public static ThemeType CurrentTheme 
    { 
        get => _currentTheme;
        private set
        {
            if (_currentTheme != value)
            {
                _currentTheme = value;
                ThemeChanged?.Invoke(null, value);
            }
        }
    }

    public static bool IsLight => _currentTheme == ThemeType.Light;

    public static event EventHandler<ThemeType>? ThemeChanged;

    public static void Initialize()
    {
        try
        {
            if (File.Exists(ThemeFile))
            {
                var content = File.ReadAllText(ThemeFile).Trim();
                if (Enum.TryParse<ThemeType>(content, ignoreCase: true, out var parsedTheme))
                {
                    CurrentTheme = parsedTheme;
                }
                else
                {
                    CurrentTheme = ThemeType.Dark;
                    LogService.Log($"Bilinmeyen tema türü '{content}' yoksayıldı.", "WARN");
                }
            }
            else
            {
                CurrentTheme = ThemeType.System;
            }
        }
        catch (Exception ex)
        {
            LogService.Log($"Tema başlatılırken hata: {ex.Message}", "ERROR");
            CurrentTheme = ThemeType.Dark;
        }

        ApplyTheme(persist: false);
    }

    public static void SetTheme(ThemeType theme)
    {
        if (CurrentTheme == theme)
        {
            return;
        }

        CurrentTheme = theme;
        ApplyTheme(persist: true);
    }

    public static void Toggle()
    {
        var nextTheme = CurrentTheme switch
        {
            ThemeType.Dark => ThemeType.Light,
            ThemeType.Light => ThemeType.Dark,
            ThemeType.System or ThemeType.Auto => IsLight ? ThemeType.Dark : ThemeType.Light,
            _ => ThemeType.Dark
        };

        SetTheme(nextTheme);
    }

    private static void ApplyTheme(bool persist)
    {
        try
        {
            var app = Application.Current;
            if (app is null)
            {
                LogService.Log("Uygulama bağlamı kullanılamıyor.", "WARN");
                return;
            }

            bool isLightTheme = CurrentTheme switch
            {
                ThemeType.Light => true,
                ThemeType.Dark => false,
                ThemeType.System => GetSystemIsDarkMode(),
                ThemeType.Auto => GetSystemIsDarkMode(),
                _ => false
            };

            ApplyColors(isLightTheme);

            if (persist)
            {
                PersistTheme();
            }
        }
        catch (Exception ex)
        {
            LogService.Log($"Tema uygulanırken hata: {ex.Message}", "ERROR");
        }
    }

    private static void ApplyColors(bool light)
    {
        SetColor("DarkColor", light ? "#F1F5F9" : "#0A1628");
        SetColor("DarkerColor", light ? "#E2E8F0" : "#050D18");
        SetColor("CardColor", light ? "#F8FAFC" : "#0F1E30");
        SetColor("BorderColor", light ? "#CBD5E1" : "#1E3A5F");
        SetColor("TextPrimaryColor", light ? "#0F172A" : "#FFFFFF");
        SetColor("TextSecondaryColor", light ? "#475569" : "#8892B0");
        SetColor("AccentColor", light ? "#3B82F6" : "#60A5FA");
        SetColor("SuccessColor", light ? "#10B981" : "#34D399");
        SetColor("WarningColor", light ? "#F59E0B" : "#FBBF24");
        SetColor("ErrorColor", light ? "#EF4444" : "#F87171");
    }

    private static void PersistTheme()
    {
        try
        {
            var dir = Path.GetDirectoryName(ThemeFile);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
                File.WriteAllText(ThemeFile, CurrentTheme.ToString());
                LogService.Log($"Tema kaydedildi: {CurrentTheme}", "INFO");
            }
        }
        catch (Exception ex)
        {
            LogService.Log($"Tema tercihi kaydedilemedi: {ex.Message}", "WARN");
        }
    }

    private static bool GetSystemIsDarkMode()
    {
        try
        {
            var registryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");

            if (registryKey?.GetValue("AppsUseLightTheme") is int value)
            {
                return value == 0;
            }
        }
        catch (Exception ex)
        {
            LogService.Log($"Sistem tema ayarı okunamadı: {ex.Message}", "WARN");
        }

        return false;
    }

    private static void SetColor(string key, string hex)
    {
        try
        {
            var app = Application.Current;
            if (app?.Resources is null)
            {
                return;
            }

            var color = ParseColor(hex);
            SetColor(app.Resources, key, color);
        }
        catch (Exception ex)
        {
            LogService.Log($"Renk ayarlanırken hata '{key}': {ex.Message}", "WARN");
        }
    }

    private static void SetColor(ResourceDictionary resources, string key, Color color)
    {
        if (resources is null)
        {
            return;
        }

        resources[key] = color;

        foreach (var merged in resources.MergedDictionaries)
        {
            SetColor(merged, key, color);
        }
    }

    private static Color ParseColor(string hex)
    {
        if (string.IsNullOrWhiteSpace(hex))
        {
            return Colors.Black;
        }

        try
        {
            return (Color)ColorConverter.ConvertFromString(hex);
        }
        catch (Exception ex)
        {
            LogService.Log($"Renk '{hex}' ayrıştırılamadı: {ex.Message}", "WARN");
            return Colors.Black;
        }
    }
}
