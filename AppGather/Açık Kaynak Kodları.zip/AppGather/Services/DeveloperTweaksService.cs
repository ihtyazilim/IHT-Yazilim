﻿using System.Collections.ObjectModel;
using AppGather.Models;

namespace AppGather.Services;

public static class DeveloperTweaksService
{
    public static ObservableCollection<TweakItem> GetList() => new()
    {
        new()
        {
            Id = "danger1",
            Name = "Windows Update'i Kapat",
            Category = "Tehlikeli",
            IsDangerous = true,
            IsSecurityCritical = true,
            IsDeveloper = true,
            Description = "Tüm güncellemeleri kapatır. Güvenlik açıklarına neden olabilir.",
            ApplyCommand = "Set-Service wuauserv -StartupType Disabled -ErrorAction SilentlyContinue; Stop-Service wuauserv -Force -ErrorAction SilentlyContinue; Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU' -Name 'NoAutoUpdate' -Value 1 -Force -ErrorAction SilentlyContinue",
            RevertCommand = "Set-Service wuauserv -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service wuauserv -ErrorAction SilentlyContinue; Remove-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU' -Name 'NoAutoUpdate' -Force -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "danger2",
            Name = "Windows Defender'i Kapat",
            Category = "Tehlikeli",
            IsDangerous = true,
            IsSecurityCritical = true,
            IsDeveloper = true,
            Description = "Gerçek zamanlı korumayı kapatır. Virüs riski ortaya çıkar.",
            ApplyCommand = "Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue; Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows Defender' -Name 'DisableAntiSpyware' -Value 1 -Force -ErrorAction SilentlyContinue",
            RevertCommand = "Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue; Remove-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows Defender' -Name 'DisableAntiSpyware' -Force -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "danger3",
            Name = "Windows Firewall'u Kapat",
            Category = "Tehlikeli",
            IsDangerous = true,
            IsDeveloper = true,
            Description = "Güvenlik duvarını kapatır. Ağ saldırılarına açık hale gelir.",
            ApplyCommand = "Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False -ErrorAction SilentlyContinue",
            RevertCommand = "Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "danger4",
            Name = "UAC'i Kapat",
            Category = "Tehlikeli",
            IsDangerous = true,
            IsDeveloper = true,
            Description = "Kullanıcı Hesabı Denetimi'ni kapatır. Uzak kod çalıştırma riski doğar.",
            ApplyCommand = "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name 'EnableLUA' -Value 0 -Force -ErrorAction SilentlyContinue",
            RevertCommand = "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name 'EnableLUA' -Value 1 -Force -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "danger5",
            Name = "Sistem Geri Yüklemeyi Kapat",
            Category = "Tehlikeli",
            IsDangerous = true,
            IsDeveloper = true,
            Description = "Geri yükleme noktalarını devre dışı bırakır. Sorun oluşursa geri dönüş yoktur.",
            ApplyCommand = "Disable-ComputerRestore -Drive \"$env:SystemDrive\" -ErrorAction SilentlyContinue",
            RevertCommand = "Enable-ComputerRestore -Drive \"$env:SystemDrive\" -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "danger7",
            Name = "Hazırda Bekletmeyi Kapat",
            Category = "Güç",
            IsDangerous = false,
            IsDeveloper = false,
            Description = "Hazırda bekletmeyi kapatır ve hiberfil.sys dosyasını siler.",
            ApplyCommand = "powercfg.exe /hibernate off",
            RevertCommand = "powercfg.exe /hibernate on"
        },
        new()
        {
            Id = "power1",
            Name = "NumLock'u açılışta etkinleştir",
            Category = "Güç ve açılış",
            Description = "Windows açılışında NumLock durumunu etkinleştirir.",
            ApplyCommand = "New-Item -Path 'HKCU:\\Control Panel\\Keyboard' -Force | Out-Null; Set-ItemProperty -Path 'HKCU:\\Control Panel\\Keyboard' -Name InitialKeyboardIndicators -Value '2' -Force",
            RevertCommand = "Set-ItemProperty -Path 'HKCU:\\Control Panel\\Keyboard' -Name InitialKeyboardIndicators -Value '0' -Force"
        },
        new()
        {
            Id = "appearance1",
            Name = "Windows koyu teması",
            Category = "Görünüm",
            Description = "Windows uygulama ve sistem temasını koyu moda alır.",
            ApplyCommand = "$p='HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize'; New-Item -Path $p -Force | Out-Null; Set-ItemProperty -Path $p -Name AppsUseLightTheme -Value 0 -Force; Set-ItemProperty -Path $p -Name SystemUsesLightTheme -Value 0 -Force",
            RevertCommand = "$p='HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize'; Set-ItemProperty -Path $p -Name AppsUseLightTheme -Value 1 -Force; Set-ItemProperty -Path $p -Name SystemUsesLightTheme -Value 1 -Force"
        },
        new()
        {
            Id = "startup1",
            Name = "Razer otomatik başlangıcını kapat",
            Category = "Başlangıç",
            Description = "Razer hizmetlerini otomatik başlatmaz; cihaz sürücülerini kaldırmaz.",
            ApplyCommand = "Get-Service | Where-Object { $_.Name -match 'Razer' } | ForEach-Object { Stop-Service $_.Name -Force -ErrorAction SilentlyContinue; Set-Service $_.Name -StartupType Disabled -ErrorAction SilentlyContinue }",
            RevertCommand = "Get-Service | Where-Object { $_.Name -match 'Razer' } | ForEach-Object { Set-Service $_.Name -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service $_.Name -ErrorAction SilentlyContinue }"
        },
        new()
        {
            Id = "adv1",
            Name = "DNS'i Cloudflare Yap",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "Daha hızlı DNS çözümlemesi için 1.1.1.1 ve 1.0.0.1 kullanır.",
            ApplyCommand = "Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') -ErrorAction SilentlyContinue }",
            RevertCommand = "Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses -ErrorAction SilentlyContinue }"
        },
        new()
        {
            Id = "adv3",
            Name = "God Mode Klasörü Oluştur",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "Masaüstünde tüm Windows ayarlarına tek yerden erişim sağlar.",
            ApplyCommand = "$path = [Environment]::GetFolderPath('Desktop') + '\\GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}'; New-Item -Path $path -ItemType Directory -Force -ErrorAction SilentlyContinue",
            RevertCommand = "$path = [Environment]::GetFolderPath('Desktop') + '\\GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}'; Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "adv5",
            Name = "Ağ Ayarlarını Sıfırla",
            Category = "Gelişmiş",
            IsDangerous = true,
            IsDeveloper = true,
            Description = "Tüm ağ adaptörlerini sıfırlar. İnternet geçici olarak kesilir.",
            ApplyCommand = "netsh winsock reset; netsh int ip reset; ipconfig /flushdns -ErrorAction SilentlyContinue",
            RevertCommand = "# Otomatik geri alma yok."
        },
        new()
        {
            Id = "adv7",
            Name = "SFC ile Sistem Dosyalarını Tara",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "Bozuk sistem dosyalarını tarar ve onarır. 5-10 dakika sürebilir.",
            ApplyCommand = "sfc /scannow -ErrorAction SilentlyContinue",
            RevertCommand = "# Otomatik geri alma yok."
        },
        new()
        {
            Id = "adv8",
            Name = "DISM ile Sistemi Onar",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "Windows imajını onarır. 10-30 dakika sürebilir.",
            ApplyCommand = "DISM /Online /Cleanup-Image /RestoreHealth -ErrorAction SilentlyContinue",
            RevertCommand = "# Otomatik geri alma yok."
        },
        new()
        {
            Id = "adv10",
            Name = "SSD TRIM Aktifleştir",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "SSD diskler için TRIM özelliğini etkinleştirir.",
            ApplyCommand = "fsutil behavior set DisableDeleteNotify 0 -ErrorAction SilentlyContinue",
            RevertCommand = "fsutil behavior set DisableDeleteNotify 1 -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "adv11",
            Name = "Xbox Game DVR'ı Kapat",
            Category = "Gelişmiş",
            IsDeveloper = true,
            Description = "Arka plan oyun kaydını kapatır, CPU ve GPU kullanımını azaltır.",
            ApplyCommand = "Set-ItemProperty -Path 'HKCU:\\System\\GameConfigStore' -Name 'GameDVR_Enabled' -Value 0 -Force -ErrorAction SilentlyContinue; Set-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -Force -ErrorAction SilentlyContinue",
            RevertCommand = "Set-ItemProperty -Path 'HKCU:\\System\\GameConfigStore' -Name 'GameDVR_Enabled' -Value 1 -Force -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "privacy1",
            Name = "Windows telemetrisini kapat",
            Category = "Gizlilik",
            IsDeveloper = true,
            Description = "Tanılama verisi ilkesini minimuma indirir ve Connected User Experiences and Telemetry hizmetini durdurur. Bazı tanılama özellikleri çalışmayabilir.",
            ApplyCommand = "New-Item -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection' -Force | Out-Null; New-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection' -Name 'AllowTelemetry' -PropertyType DWord -Value 0 -Force; Set-Service -Name DiagTrack -StartupType Disabled -ErrorAction SilentlyContinue; Stop-Service -Name DiagTrack -Force -ErrorAction SilentlyContinue",
            RevertCommand = "New-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection' -Name 'AllowTelemetry' -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue; Set-Service -Name DiagTrack -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service -Name DiagTrack -ErrorAction SilentlyContinue"
        },
        new()
        {
            Id = "privacy2",
            Name = "Reklam kimliği ve kişiselleştirmeyi kapat",
            Category = "Gizlilik",
            IsDeveloper = true,
            Description = "Kullanıcı reklam kimliğini ve Windows öneri/kişiselleştirme sinyallerini kapatır.",
            ApplyCommand = "New-Item -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo' -Name 'Enabled' -PropertyType DWord -Value 0 -Force; New-Item -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Privacy' -Force | Out-Null; New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -PropertyType DWord -Value 0 -Force",
            RevertCommand = "New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo' -Name 'Enabled' -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue; New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue"
        }
    };
}
