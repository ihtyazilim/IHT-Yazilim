﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using AppGather.Models;

namespace AppGather.Services;

public static class AppInstallService
{
    public static ObservableCollection<AppItem> GetList() => new()
    {
        new() { Id = "chrome", Name = "Google Chrome", Category = "Tarayıcılar", WingetId = "Google.Chrome" },
        new() { Id = "firefox", Name = "Mozilla Firefox", Category = "Tarayıcılar", WingetId = "Mozilla.Firefox" },
        new() { Id = "brave", Name = "Brave", Category = "Tarayıcılar", WingetId = "Brave.Brave" },
        new() { Id = "vlc", Name = "VLC", Category = "Medya", WingetId = "VideoLAN.VLC" },
        new() { Id = "spotify", Name = "Spotify", Category = "Medya", WingetId = "Spotify.Spotify" },
        new() { Id = "audacity", Name = "Audacity", Category = "Medya", WingetId = "Audacity.Audacity" },
        new() { Id = "vscode", Name = "VS Code", Category = "Geliştirme", WingetId = "Microsoft.VisualStudioCode" },
        new() { Id = "git", Name = "Git", Category = "Geliştirme", WingetId = "Git.Git" },
        new() { Id = "npp", Name = "Notepad++", Category = "Geliştirme", WingetId = "Notepad++.Notepad++" },
        new() { Id = "python", Name = "Python 3.12", Category = "Geliştirme", WingetId = "Python.Python.3.12" },
        new() { Id = "node", Name = "Node.js", Category = "Geliştirme", WingetId = "OpenJS.NodeJS" },
        new() { Id = "7zip", Name = "7-Zip", Category = "Araçlar", WingetId = "7zip.7zip" },
        new() { Id = "winrar", Name = "WinRAR", Category = "Araçlar", WingetId = "RARLab.WinRAR" },
        new() { Id = "everything", Name = "Everything", Category = "Araçlar", WingetId = "voidtools.Everything" },
        new() { Id = "sharex", Name = "ShareX", Category = "Araçlar", WingetId = "ShareX.ShareX" },
        new() { Id = "discord", Name = "Discord", Category = "İletişim", WingetId = "Discord.Discord" },
        new() { Id = "telegram", Name = "Telegram", Category = "İletişim", WingetId = "Telegram.TelegramDesktop" },
        new() { Id = "zoom", Name = "Zoom", Category = "İletişim", WingetId = "Zoom.Zoom" },
        new() { Id = "steam", Name = "Steam", Category = "Oyun", WingetId = "Valve.Steam" },
        new() { Id = "epic", Name = "Epic Games", Category = "Oyun", WingetId = "EpicGames.EpicGamesLauncher" },
        new() { Id = "malwarebytes", Name = "Malwarebytes", Category = "Güvenlik", WingetId = "Malwarebytes.Malwarebytes" },
        new() { Id = "bitwarden", Name = "Bitwarden", Category = "Güvenlik", WingetId = "Bitwarden.Bitwarden" },
        new() { Id = "libreoffice", Name = "LibreOffice", Category = "Ofis", WingetId = "TheDocumentFoundation.LibreOffice" },
        new() { Id = "adobe", Name = "Adobe Reader", Category = "Ofis", WingetId = "Adobe.Acrobat.Reader.64-bit" }
    };

    public static async Task<bool> InstallAsync(AppItem item)
    {
        LogService.Log($"Kuruluyor: {item.Name}", "INFO");

        var result = await PowerShellService.RunAsync(
            $"winget install --id {item.WingetId} -e --silent --accept-source-agreements --accept-package-agreements");

        if (result.ExitCode == 0)
        {
            LogService.Log($"{item.Name} kuruldu.", "SUCCESS");
            return true;
        }

        var errorMessage = string.IsNullOrWhiteSpace(result.Error) ? "Kurulum başarısız oldu." : result.Error;
        LogService.Log($"{item.Name} kurulamadı: {errorMessage}", "ERROR");
        return false;
    }
}
