using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace AppGather.Services;

public enum DnsCategory
{
    Cloudflare,
    Google,
    Quad9,
    Custom
}

public class DnsProfile
{
    public string Name { get; set; } = string.Empty;
    public DnsCategory Category { get; set; }
    public string[] Addresses { get; set; } = Array.Empty<string>();
    public string Description { get; set; } = string.Empty;

    public override string ToString() => Name;
}

public static class NetworkService
{
    private static readonly Dictionary<string, DnsProfile[]> GroupedDnsProfiles = new()
    {
        { "Cloudflare", new[] {
            new DnsProfile { Name = "Cloudflare", Category = DnsCategory.Cloudflare, Addresses = ["1.1.1.1", "1.0.0.1"], Description = "Gizlilik odaklı DNS" },
            new DnsProfile { Name = "Cloudflare Malware Filter", Category = DnsCategory.Cloudflare, Addresses = ["1.1.1.2", "1.0.0.2"], Description = "Kötü amaçlı yazılım filtreleme" },
            new DnsProfile { Name = "Cloudflare Adult Filter", Category = DnsCategory.Cloudflare, Addresses = ["1.1.1.3", "1.0.0.3"], Description = "Yetişkin içeriği filtreleme" }
        }},
        { "Google", new[] {
            new DnsProfile { Name = "Google", Category = DnsCategory.Google, Addresses = ["8.8.8.8", "8.8.4.4"], Description = "Google Halk DNS" }
        }},
        { "Quad9", new[] {
            new DnsProfile { Name = "Quad9", Category = DnsCategory.Quad9, Addresses = ["9.9.9.9", "149.112.112.112"], Description = "Siber güvenlik baltalama" }
        }}
    };

    private static readonly ObservableCollection<DnsProfile> CustomDnsProfiles = new();

    public static IReadOnlyDictionary<string, DnsProfile[]> DnsProfiles => GroupedDnsProfiles;
    public static IReadOnlyList<DnsProfile> CustomProfiles => CustomDnsProfiles;

    public static DnsProfile? GetProfileByName(string name)
    {
        foreach (var profiles in GroupedDnsProfiles.Values)
        {
            var profile = profiles.FirstOrDefault(p => p.Name == name);
            if (profile is not null)
                return profile;
        }

        return CustomDnsProfiles.FirstOrDefault(p => p.Name == name);
    }

    public static bool AddCustomDnsProfile(string name, string[] addresses, string description = "")
    {
        try
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                LogService.Log("Özel DNS profili adı boş olamaz.", "WARN");
                return false;
            }

            var validAddresses = addresses
                .Where(addr => IPAddress.TryParse(addr.Trim(), out _))
                .Distinct()
                .ToArray();

            if (validAddresses.Length == 0)
            {
                LogService.Log("Geçerli DNS adresi bulunamadı.", "WARN");
                return false;
            }

            var profile = new DnsProfile
            {
                Name = name,
                Category = DnsCategory.Custom,
                Addresses = validAddresses,
                Description = string.IsNullOrWhiteSpace(description) ? "Özel DNS" : description
            };

            CustomDnsProfiles.Add(profile);
            LogService.Log($"Özel DNS profili eklendi: {name}", "INFO");
            return true;
        }
        catch (Exception ex)
        {
            LogService.Log($"Özel DNS profili eklenirken hata: {ex.Message}", "ERROR");
            return false;
        }
    }

    public static bool RemoveCustomDnsProfile(string name)
    {
        try
        {
            var profile = CustomDnsProfiles.FirstOrDefault(p => p.Name == name);
            if (profile is null)
            {
                LogService.Log($"Özel DNS profili bulunamadı: {name}", "WARN");
                return false;
            }

            CustomDnsProfiles.Remove(profile);
            LogService.Log($"Özel DNS profili kaldırıldı: {name}", "INFO");
            return true;
        }
        catch (Exception ex)
        {
            LogService.Log($"Özel DNS profili kaldırılırken hata: {ex.Message}", "ERROR");
            return false;
        }
    }

    public static Task<(int ExitCode, string Output, string Error)> TestConnectionAsync()
    {
        return PowerShellService.RunAsync("Test-Connection -ComputerName 1.1.1.1 -Count 1 -Quiet");
    }

    public static Task<(int ExitCode, string Output, string Error)> TestDnsAsync(string ipAddress)
    {
        return PowerShellService.RunAsync($"Resolve-DnsName -Name example.com -Server {ipAddress} -ErrorAction Stop");
    }

    public static Task<bool> FlushDnsAsync()
    {
        return PowerShellService.RunSilentAsync("Clear-DnsClientCache");
    }

    public static Task<bool> RenewIpAsync()
    {
        return PowerShellService.RunSilentAsync("ipconfig /release; ipconfig /renew");
    }

    public static Task<bool> ApplyDnsAsync(IEnumerable<string> addresses)
    {
        try
        {
            var values = addresses.Where(address => IPAddress.TryParse(address?.Trim() ?? string.Empty, out _)).Distinct().ToArray();
            if (values.Length == 0)
            {
                LogService.Log("Geçerli DNS adresi yok.", "WARN");
                return Task.FromResult(false);
            }

            var powershellValues = string.Join(",", values.Select(address => $"'{address}'"));
            var command = $"Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object {{ Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ({powershellValues}) -ErrorAction Stop }}";

            LogService.Log($"DNS uygulanıyor: {string.Join(", ", values)}", "INFO");
            return PowerShellService.RunSilentAsync(command);
        }
        catch (Exception ex)
        {
            LogService.Log($"DNS uygulanırken hata: {ex.Message}", "ERROR");
            return Task.FromResult(false);
        }
    }

    public static async Task<bool> ApplyDnsProfileAsync(DnsProfile? profile)
    {
        if (profile is null)
        {
            LogService.Log("DNS profili null.", "WARN");
            return false;
        }

        try
        {
            LogService.Log($"DNS profili uygulanıyor: {profile.Name}", "INFO");
            return await ApplyDnsAsync(profile.Addresses);
        }
        catch (Exception ex)
        {
            LogService.Log($"DNS profili uygulanırken hata: {ex.Message}", "ERROR");
            return false;
        }
    }
}
