using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace AppGather.Services;

public static class PowerShellService
{
    private const int ExecutionTimeoutMilliseconds = 120000;

    public static async Task<(int ExitCode, string Output, string Error)> RunAsync(string command)
    {
        var normalizedCommand = NormalizeCommand(command);

        if (normalizedCommand.Length == 0)
        {
            return (-1, string.Empty, "PowerShell komutu boş olamaz.");
        }

        try
        {
            var systemDirectory = Environment.GetFolderPath(Environment.SpecialFolder.System);
            var executable = Path.Combine(systemDirectory, "WindowsPowerShell", "v1.0", "powershell.exe");
            if (!File.Exists(executable))
            {
                return (-1, string.Empty, "Windows PowerShell bulunamadı.");
            }

            var startInfo = new ProcessStartInfo
            {
                FileName = executable,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            startInfo.ArgumentList.Add("-NoProfile");
            startInfo.ArgumentList.Add("-ExecutionPolicy");
            startInfo.ArgumentList.Add("Bypass");
            startInfo.ArgumentList.Add("-Command");
            startInfo.ArgumentList.Add(normalizedCommand);

            using var process = Process.Start(startInfo);
            if (process is null)
            {
                return (-1, string.Empty, "PowerShell başlatılamadı.");
            }

            var outputTask = process.StandardOutput.ReadToEndAsync();
            var errorTask = process.StandardError.ReadToEndAsync();
            try
            {
                await process.WaitForExitAsync().WaitAsync(
                    TimeSpan.FromMilliseconds(ExecutionTimeoutMilliseconds));
            }
            catch (TimeoutException)
            {
                process.Kill(entireProcessTree: true);
                var timeoutOutput = await outputTask;
                var timeoutError = await errorTask;
                return (-1, timeoutOutput, timeoutError.Length > 0
                    ? timeoutError
                    : "İşlem zaman aşımına uğradı.");
            }

            return (process.ExitCode, await outputTask, await errorTask);
        }
        catch (TimeoutException)
        {
            // Zaman aşımında işlem daha sonra kapanıp kaynak bırakmasın.
            return (-1, string.Empty, "İşlem zaman aşımına uğradı.");
        }
        catch (Exception exception)
        {
            return (-1, string.Empty, exception.Message);
        }
    }

    public static async Task<bool> RunSilentAsync(string command)
    {
        var result = await RunAsync(command);
        if (result.ExitCode == 0)
        {
            return true;
        }

        if (!string.IsNullOrWhiteSpace(result.Error))
        {
            LogService.Log($"PowerShell hatası: {result.Error}", "ERROR");
        }

        return false;
    }

    private static string NormalizeCommand(string command)
    {
        if (string.IsNullOrWhiteSpace(command))
        {
            return string.Empty;
        }

        return command.Trim();
    }
}
