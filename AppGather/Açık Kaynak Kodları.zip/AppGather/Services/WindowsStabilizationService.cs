using System;
using System.Threading.Tasks;

namespace AppGather.Services;

public static class WindowsStabilizationService
{
    public static async Task<(bool Success, string Details)> ApplyAsync()
    {
        const string command = @"
$ErrorActionPreference = 'SilentlyContinue'
$results = [System.Collections.Generic.List[string]]::new()

# Insider/Preview/Beta derlemelerini politika ile engelle; kararlı Windows Update açık kalır.
$previewPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
New-Item -Path $previewPolicy -Force | Out-Null
New-ItemProperty -Path $previewPolicy -Name 'DisablePreviewBuilds' -PropertyType DWord -Value 1 -Force | Out-Null
New-ItemProperty -Path $previewPolicy -Name 'ManagePreviewBuilds' -PropertyType DWord -Value 0 -Force | Out-Null
New-ItemProperty -Path $previewPolicy -Name 'BranchReadinessLevel' -PropertyType DWord -Value 0 -Force | Out-Null
$results.Add('Insider/Beta/Preview kanalları kapatıldı')

# Telemetriyi politika ve ilgili tanılama servisi seviyesinde kapat.
$telemetryPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'
New-Item -Path $telemetryPolicy -Force | Out-Null
New-ItemProperty -Path $telemetryPolicy -Name 'AllowTelemetry' -PropertyType DWord -Value 0 -Force | Out-Null
New-ItemProperty -Path $telemetryPolicy -Name 'MaxTelemetryAllowed' -PropertyType DWord -Value 0 -Force | Out-Null
Set-Service -Name 'DiagTrack' -StartupType Disabled
Stop-Service -Name 'DiagTrack' -Force
$results.Add('Telemetri kapatıldı')

# Reklam kimliği, önerilen uygulamalar ve içerik önerilerini kapat.
$cdm = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
New-Item -Path $cdm -Force | Out-Null
@('ContentDeliveryAllowed','FeatureManagementEnabled','OemPreInstalledAppsEnabled','PreInstalledAppsEnabled','PreInstalledAppsEverEnabled','SilentInstalledAppsEnabled','SystemPaneSuggestionsEnabled','SubscribedContent-338388Enabled','SubscribedContent-338389Enabled','SubscribedContent-353694Enabled','SubscribedContent-353696Enabled') | ForEach-Object { New-ItemProperty -Path $cdm -Name $_ -PropertyType DWord -Value 0 -Force | Out-Null }
$privacy = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo'
New-Item -Path $privacy -Force | Out-Null
New-ItemProperty -Path $privacy -Name 'Enabled' -PropertyType DWord -Value 0 -Force | Out-Null
$results.Add('Reklam ve öneriler kapatıldı')

# Delivery Optimization eşler arası paylaşımını kapat; Windows Update servisini kapatma.
$delivery = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
New-Item -Path $delivery -Force | Out-Null
New-ItemProperty -Path $delivery -Name 'DODownloadMode' -PropertyType DWord -Value 100 -Force | Out-Null
$results.Add('Teslim İyileştirmesi eşler arası indirmesi kapatıldı')

# Defender, Windows Update, Firewall ve UAC bu işlemde değiştirilmez.
$results.Add('Defender ve kararlı Windows Update korundu')
[Environment]::SetEnvironmentVariable('APPGATHER_STABILIZATION_APPLIED', '1', 'Machine')
$results -join [Environment]::NewLine
";

        var result = await PowerShellService.RunAsync(command);
        if (result.ExitCode != 0)
            return (false, string.IsNullOrWhiteSpace(result.Error) ? "Windows ayarları uygulanamadı." : result.Error.Trim());

        LogService.Log("Windows stabilizasyonu uygulandı.", "SUCCESS");
        return (true, string.IsNullOrWhiteSpace(result.Output) ? "Ayarlar uygulandı." : result.Output.Trim());
    }
}
