﻿using System.Threading.Tasks;
using System.Windows;

namespace AppGather.Services;

public static class RestorePointService
{
    public static async Task<bool> ConfirmAndCreateAsync(string description)
    {
        var answer = MessageBox.Show(
            "Bu işlem sisteminizde değişiklik yapacak. İşlemden önce geri yükleme noktası oluşturulsun mu?",
            "Geri yükleme noktası",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        if (answer != MessageBoxResult.Yes)
        {
            return true;
        }

        var created = await CreateAsync(description);
        if (created)
        {
            return true;
        }

        MessageBox.Show(
            "Geri yükleme noktası oluşturulamadı. İşlem güvenlik nedeniyle başlatılmadı.",
            "İşlem durduruldu",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
        return false;
    }

    public static async Task<bool> CreateAsync(string description = "AppGather")
    {
        if (!AdminHelper.IsAdministrator())
        {
            LogService.Log("Geri yükleme noktası oluşturmak için yönetici yetkisi gereklidir.", "WARN");
            return false;
        }

        LogService.Log("Geri yükleme noktası oluşturuluyor...", "INFO");

        var restoreEnabled = await PowerShellService.RunSilentAsync(
            "Enable-ComputerRestore -Drive \"$env:SystemDrive\" -ErrorAction SilentlyContinue");

        if (!restoreEnabled)
        {
            LogService.Log("Geri yükleme noktası özelliği etkinleştirilemedi.", "WARN");
            return false;
        }

        var safeDescription = description.Replace("'", "''", StringComparison.Ordinal);
        var command = $"Checkpoint-Computer -Description '{safeDescription}' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop";
        var result = await PowerShellService.RunAsync(command);

        if (result.ExitCode == 0)
        {
            LogService.Log("Geri yükleme noktası oluşturuldu.", "SUCCESS");
            return true;
        }

        var errorMessage = string.IsNullOrWhiteSpace(result.Error) ? "Bilinmeyen neden." : result.Error;
        LogService.Log($"Geri yükleme noktası oluşturulamadı: {errorMessage}", "WARN");
        return false;
    }
}
