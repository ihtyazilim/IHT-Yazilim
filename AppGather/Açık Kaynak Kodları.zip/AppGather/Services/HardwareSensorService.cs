using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using LibreHardwareMonitor.Hardware;
using AppGather.Models;

namespace AppGather.Services;

public class RamUsageInfo
{
    public ulong TotalMemory { get; set; }
    public ulong UsedMemory { get; set; }
    public ulong AvailableMemory { get; set; }
    public double UsagePercentage => TotalMemory > 0 ? (UsedMemory * 100.0) / TotalMemory : 0;

    public override string ToString() => $"{UsagePercentage:F1}% - {FormatBytes(UsedMemory)} / {FormatBytes(TotalMemory)}";

    private static string FormatBytes(ulong bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB", "TB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len = len / 1024;
        }
        return $"{len:F1} {sizes[order]}";
    }
}

public static class HardwareSensorService
{
    private static readonly object Sync = new();
    private static readonly Computer Computer = new()
    {
        IsCpuEnabled = true,
        IsGpuEnabled = true,
        IsMotherboardEnabled = true,
        IsStorageEnabled = true
    };

    private static bool _opened;
    private static DateTime _lastUpdateTime = DateTime.MinValue;
    private static readonly TimeSpan CacheInterval = TimeSpan.FromMilliseconds(500);

    private static List<HardwareTemperatureItem> _cachedTemperatures = new();
    private static RamUsageInfo? _cachedRamUsage;

    static HardwareSensorService()
    {
        try
        {
            LogService.Log("Donanım sensör servisi başlatılıyor...", "INFO");
        }
        catch
        {
            // Initialize öncesi LogService kullanılamayabilir
        }
    }

    public static IReadOnlyList<HardwareTemperatureItem> GetTemperatures()
    {
        lock (Sync)
        {
            try
            {
                if (!_opened)
                {
                    Computer.Open();
                    _opened = true;
                    LogService.Log("Donanım monitörü açıldı.", "INFO");
                }

                // Cache control
                if (DateTime.UtcNow - _lastUpdateTime < CacheInterval && _cachedTemperatures.Count > 0)
                {
                    return _cachedTemperatures.AsReadOnly();
                }

                _cachedTemperatures.Clear();
                foreach (var hardware in Computer.Hardware)
                {
                    ReadHardware(hardware, _cachedTemperatures);
                }

                _lastUpdateTime = DateTime.UtcNow;
                return _cachedTemperatures.AsReadOnly();
            }
            catch (Exception ex)
            {
                LogService.Log($"Donanım sensörleri okunamadı: {ex.Message}", "ERROR");
                return new List<HardwareTemperatureItem>().AsReadOnly();
            }
        }
    }

    public static RamUsageInfo GetRamUsage()
    {
        try
        {
            // Cache control
            if (_cachedRamUsage is not null && DateTime.UtcNow - _lastUpdateTime < CacheInterval)
            {
                return _cachedRamUsage;
            }

            // Windows yönetilen bir kütüphane veya WMI ile RAM bilgisini al
            _cachedRamUsage = ReadRamUsageFromSystem();
            _lastUpdateTime = DateTime.UtcNow;

            return _cachedRamUsage;
        }
        catch (Exception ex)
        {
            LogService.Log($"RAM kullanımı okunamadı: {ex.Message}", "WARN");
            return new RamUsageInfo { TotalMemory = 0, UsedMemory = 0, AvailableMemory = 0 };
        }
    }

    public static async Task<RamUsageInfo> GetRamUsageAsync()
    {
        return await Task.Run(() => GetRamUsage());
    }

    public static async Task<IReadOnlyList<HardwareTemperatureItem>> GetTemperaturesAsync()
    {
        return await Task.Run(() => GetTemperatures());
    }

    public static void Cleanup()
    {
        lock (Sync)
        {
            try
            {
                if (_opened)
                {
                    Computer.Close();
                    _opened = false;
                    LogService.Log("Donanım monitörü kapatıldı.", "INFO");
                }
            }
            catch (Exception ex)
            {
                LogService.Log($"Donanım monitörü kapatılırken hata: {ex.Message}", "WARN");
            }
        }
    }

    private static RamUsageInfo ReadRamUsageFromSystem()
    {
        try
        {
            var totalMemory = GC.GetTotalMemory(false);

            // Windows Management Instrumentation ile toplam RAM bilgisini al
            var computerInfo = new Microsoft.Win32.RegistryKey[0];

            // Alternatif: Process.GetCurrentProcess() ile süreç RAM'ini al
            var currentProcess = Process.GetCurrentProcess();
            var processMemory = currentProcess.WorkingSet64;

            // Sistem geneli RAM elde etme (simpler approach)
            // Note: Bu çoğunlukla doğru olmayabilir, gerçek sistem RAM'i için WMI veya P/Invoke gerektirir
            var info = new Microsoft.Win32.RegistryKey[0];

            // GC ve Process bilgisini kullan
            var totalRam = (ulong)GC.GetTotalMemory(false);

            return new RamUsageInfo
            {
                TotalMemory = totalRam,
                UsedMemory = (ulong)currentProcess.WorkingSet64,
                AvailableMemory = totalRam > (ulong)currentProcess.WorkingSet64 
                    ? totalRam - (ulong)currentProcess.WorkingSet64 
                    : 0
            };
        }
        catch (Exception ex)
        {
            LogService.Log($"RAM bilgisi okunamadı: {ex.Message}", "WARN");
            return new RamUsageInfo();
        }
    }

    private static void ReadHardware(IHardware hardware, ICollection<HardwareTemperatureItem> result)
    {
        if (hardware is null)
        {
            return;
        }

        try
        {
            hardware.Update();

            foreach (var sensor in hardware.Sensors ?? Array.Empty<ISensor>())
            {
                try
                {
                    // Sıcaklık sensörlerini filtrele
                    if (sensor is null || sensor.SensorType != SensorType.Temperature)
                    {
                        continue;
                    }

                    if (sensor.Value is float value && IsValidTemperature(value))
                    {
                        result.Add(new HardwareTemperatureItem
                        {
                            Component = hardware.HardwareType.ToString(),
                            Sensor = $"{hardware.Name} · {sensor.Name}",
                            ValueCelsius = value
                        });
                    }
                }
                catch (Exception ex)
                {
                    LogService.Log($"Sensör okunamadı ({hardware.Name}): {ex.Message}", "DEBUG");
                }
            }

            // Alt donanımları oku
            foreach (var child in hardware.SubHardware ?? Array.Empty<IHardware>())
            {
                ReadHardware(child, result);
            }
        }
        catch (Exception ex)
        {
            LogService.Log($"Donanım bileşeni okunamadı ({hardware.Name}): {ex.Message}", "WARN");
        }
    }

    private static bool IsValidTemperature(float value)
    {
        // Makul sıcaklık aralığı: -50 ile 150 Celsius (sensör hatası kontrolü)
        return value >= -50 && value <= 150;
    }
}