﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using AppGather.Models;

namespace AppGather.Services;

public static class BloatwareService
{
    public static ObservableCollection<BloatwareItem> GetList() => new()
    {
        new() { Id = "x1", Name = "Xbox Oyun Çubuğu", Description = "Xbox oyun çubuğu", Category = "Xbox", PackageName = "Microsoft.XboxGamingOverlay" },
        new() { Id = "x2", Name = "Xbox Uygulaması", Description = "Xbox oyun uygulaması", Category = "Xbox", PackageName = "Microsoft.GamingApp" },
        new() { Id = "x3", Name = "Xbox TCUI", Description = "Xbox arayüzü", Category = "Xbox", PackageName = "Microsoft.Xbox.TCUI" },
        new() { Id = "x4", Name = "Xbox Kimlik", Description = "Xbox kimlik bileşeni", Category = "Xbox", PackageName = "Microsoft.XboxIdentityProvider" },
        new() { Id = "x5", Name = "Xbox Konuşma", Description = "Xbox konuşma katmanı", Category = "Xbox", PackageName = "Microsoft.XboxSpeechToTextOverlay" },
        new() { Id = "b1", Name = "Bing Hava Durumu", Description = "Hava durumu", Category = "Bing", PackageName = "Microsoft.BingWeather" },
        new() { Id = "b2", Name = "Bing Haberler", Description = "Haberler", Category = "Bing", PackageName = "Microsoft.BingNews" },
        new() { Id = "b3", Name = "Bing Finans", Description = "Finans", Category = "Bing", PackageName = "Microsoft.BingFinance" },
        new() { Id = "b4", Name = "Bing Spor", Description = "Spor", Category = "Bing", PackageName = "Microsoft.BingSports" },
        new() { Id = "m1", Name = "Groove Müzik", Description = "Müzik uygulaması", Category = "Medya", PackageName = "Microsoft.ZuneMusic" },
        new() { Id = "m2", Name = "Filmler ve TV", Description = "Film dizi", Category = "Medya", PackageName = "Microsoft.ZuneVideo" },
        new() { Id = "m3", Name = "Karışık Gerçeklik", Description = "Karma gerçeklik", Category = "Medya", PackageName = "Microsoft.MixedReality.Portal" },
        new() { Id = "p1", Name = "3D Görüntüleyici", Description = "3D görüntüleyici", Category = "Üretkenlik", PackageName = "Microsoft.Microsoft3DViewer" },
        new() { Id = "p2", Name = "Paint 3D", Description = "3D boyama", Category = "Üretkenlik", PackageName = "Microsoft.MSPaint" },
        new() { Id = "p3", Name = "Office Hub", Description = "Office merkezi", Category = "Üretkenlik", PackageName = "Microsoft.MicrosoftOfficeHub" },
        new() { Id = "p4", Name = "Sway", Description = "Sunum aracı", Category = "Üretkenlik", PackageName = "Microsoft.Office.Sway" },
        new() { Id = "p5", Name = "OneNote UWP", Description = "OneNote", Category = "Üretkenlik", PackageName = "Microsoft.Office.OneNote" },
        new() { Id = "c1", Name = "Posta ve Takvim", Description = "Posta ve takvim", Category = "İletişim", PackageName = "microsoft.windowscommunicationsapps" },
        new() { Id = "c2", Name = "Kişiler", Description = "Kişi yönetimi", Category = "İletişim", PackageName = "Microsoft.People" },
        new() { Id = "c3", Name = "Skype", Description = "Skype", Category = "İletişim", PackageName = "Microsoft.SkypeApp" },
        new() { Id = "o1", Name = "Cortana", Description = "Sesli asistan", Category = "Diğer", PackageName = "Microsoft.549981C3F5F10" },
        new() { Id = "o2", Name = "Yardım", Description = "Günlük yardım", Category = "Diğer", PackageName = "Microsoft.GetHelp" },
        new() { Id = "o3", Name = "İpuçları", Description = "Kullanıcı ipuçları", Category = "Diğer", PackageName = "Microsoft.Getstarted" },
        new() { Id = "o4", Name = "Geri Bildirim Merkezi", Description = "Geri bildirim", Category = "Diğer", PackageName = "Microsoft.WindowsFeedbackHub" },
        new() { Id = "o5", Name = "Haritalar", Description = "Harita uygulaması", Category = "Diğer", PackageName = "Microsoft.WindowsMaps" },
        new() { Id = "o6", Name = "Solitaire", Description = "Kart oyunu", Category = "Diğer", PackageName = "Microsoft.MicrosoftSolitaireCollection" },
        new() { Id = "e1", Name = "Microsoft Edge", Description = "Edge Appx paketi; WebView2 ve Windows Update korunur.", Category = "Tarayıcı", PackageName = "Microsoft.MicrosoftEdge.Stable", IsRecommended = false },
        new() { Id = "r1", Name = "Razer Central", Description = "Razer yardımcı uygulaması ve bileşenleri.", Category = "Üretici yazılımı", PackageName = "Razer", IsRecommended = false },
        new() { Id = "r2", Name = "Razer Synapse", Description = "Razer cihaz yönetim yazılımı.", Category = "Üretici yazılımı", PackageName = "Razer.Synapse", IsRecommended = false },
        new() { Id = "a1", Name = "Adobe Creative Cloud", Description = "Adobe arka plan ve yardımcı uygulamaları.", Category = "Üretkenlik", PackageName = "Adobe", IsRecommended = false },
        new() { Id = "a2", Name = "Adobe Acrobat", Description = "Adobe Acrobat yardımcı bileşenleri.", Category = "Üretkenlik", PackageName = "Acrobat", IsRecommended = false },
        new() { Id = "s1", Name = "Disney+", Description = "Sponsorlu uygulama", Category = "Sponsorlu", PackageName = "Disney.37853FC22B2CE", IsRecommended = false },
        new() { Id = "s2", Name = "Spotify", Description = "Sponsorlu uygulama", Category = "Sponsorlu", PackageName = "SpotifyAB.SpotifyMusic", IsRecommended = false },
        new() { Id = "s3", Name = "Netflix", Description = "Sponsorlu uygulama", Category = "Sponsorlu", PackageName = "4DF9E0F8.Netflix", IsRecommended = false },
        new() { Id = "s4", Name = "TikTok", Description = "Sponsorlu uygulama", Category = "Sponsorlu", PackageName = "BytedancePte.Ltd.TikTok", IsRecommended = false }
    };

    public static async Task<bool> RemoveAsync(BloatwareItem item)
    {
        LogService.Log($"Kaldırılıyor: {item.Name}", "INFO");

        var command = $"$name = '{item.PackageName}'; $packages = @(Get-AppxPackage -AllUsers | Where-Object Name -like \"*$name*\"); $provisioned = @(Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like \"*$name*\"); if ($packages.Count -eq 0 -and $provisioned.Count -eq 0) {{ Write-Error 'Paket bulunamadı'; exit 2 }}; $packages | Remove-AppxPackage -ErrorAction SilentlyContinue; $provisioned | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue; exit 0";
        var result = await PowerShellService.RunAsync(command);

        if (result.ExitCode != 0)
        {
            LogService.Log($"{item.Name} kaldırılamadı: {result.Error}", "WARN");
            return false;
        }

        LogService.Log($"{item.Name} kaldırıldı.", "SUCCESS");
        return true;
    }
}
