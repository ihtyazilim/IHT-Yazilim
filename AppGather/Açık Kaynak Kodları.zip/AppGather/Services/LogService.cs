using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using AppGather.Models;

namespace AppGather.Services;

public enum LogLevel
{
    Debug,
    Info,
    Warn,
    Error,
    Critical
}

public static class LogService
{
    private const int MaximumEntries = 1000;
    private const long MaxLogFileSizeBytes = 10 * 1024 * 1024; // 10 MB
    private const int MaxLogFiles = 10;

    private static string _logDirectory = string.Empty;
    private static string _logFile = string.Empty;
    private static readonly object _syncLock = new();
    private static readonly SemaphoreSlim _fileWriteSemaphore = new(1, 1);

    public static ObservableCollection<LogEntry> Entries { get; } = new();

    public static void Initialize()
    {
        try
        {
            _logDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "AppGather",
                "logs");

            Directory.CreateDirectory(_logDirectory);
            _logFile = Path.Combine(_logDirectory, $"appgather_{DateTime.Now:yyyyMMdd_HHmmss}.log");

            CleanupOldLogs();
            Log("Günlüğe kaydı başlatıldı.", "INFO");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Günlük başlatılırken hata: {ex.Message}");
        }
    }

    public static void Log(string message, string level = "INFO")
    {
        LogAsync(message, level).GetAwaiter().GetResult();
    }

    public static async Task LogAsync(string message, string level = "INFO")
    {
        if (string.IsNullOrWhiteSpace(message))
        {
            return;
        }

        try
        {
            var entry = new LogEntry
            {
                Timestamp = DateTime.Now,
                Message = message.Trim(),
                Level = level
            };

            AddToCollection(entry);
            await WriteToFileAsync(entry);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Günlüğe kaydedilirken hata: {ex.Message}");
        }
    }

    public static void Clear()
    {
        lock (_syncLock)
        {
            Entries.Clear();
        }

        try
        {
            if (!string.IsNullOrWhiteSpace(_logFile) && File.Exists(_logFile))
            {
                File.WriteAllText(_logFile, string.Empty);
                Log("Günlük temizlendi.", "INFO");
            }
        }
        catch (Exception ex)
        {
            Log($"Günlük temizlenirken hata: {ex.Message}", "WARN");
        }
    }

    public static string? GetLogDirectory() => _logDirectory;

    public static void OpenLogFolder()
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(_logDirectory) && Directory.Exists(_logDirectory))
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = _logDirectory,
                    UseShellExecute = true
                });
            }
        }
        catch (Exception ex)
        {
            Log($"Günlük klasörü açılırken hata: {ex.Message}", "WARN");
        }
    }

    private static void AddToCollection(LogEntry entry)
    {
        var app = Application.Current;
        if (app is null)
        {
            lock (_syncLock)
            {
                Entries.Add(entry);
                TrimEntries();
            }
            return;
        }

        app.Dispatcher.Invoke(() =>
        {
            lock (_syncLock)
            {
                Entries.Add(entry);
                TrimEntries();
            }
        });
    }

    private static void TrimEntries()
    {
        while (Entries.Count > MaximumEntries)
        {
            Entries.RemoveAt(0);
        }
    }

    private static async Task WriteToFileAsync(LogEntry entry)
    {
        if (string.IsNullOrWhiteSpace(_logFile))
        {
            return;
        }

        try
        {
            await _fileWriteSemaphore.WaitAsync();

            try
            {
                await CheckAndRotateLogFileAsync();

                var logLine = entry.FormattedLine;
                await File.AppendAllTextAsync(_logFile, logLine + Environment.NewLine);
            }
            finally
            {
                _fileWriteSemaphore.Release();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Dosyaya yazarken hata: {ex.Message}");
        }
    }

    private static async Task CheckAndRotateLogFileAsync()
    {
        try
        {
            if (!File.Exists(_logFile))
            {
                return;
            }

            var fileInfo = new FileInfo(_logFile);
            if (fileInfo.Length > MaxLogFileSizeBytes)
            {
                var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                var backupFile = Path.Combine(_logDirectory, $"appgather_{timestamp}.log");
                File.Move(_logFile, backupFile, overwrite: false);
                _logFile = Path.Combine(_logDirectory, $"appgather_{DateTime.Now:yyyyMMdd_HHmmss}.log");

                CleanupOldLogs();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Günlük döndürülürken hata: {ex.Message}");
        }
    }

    private static void CleanupOldLogs()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_logDirectory) || !Directory.Exists(_logDirectory))
            {
                return;
            }

            var logFiles = Directory.GetFiles(_logDirectory, "appgather_*.log")
                .Select(f => new FileInfo(f))
                .OrderByDescending(f => f.CreationTime)
                .ToArray();

            for (int i = MaxLogFiles; i < logFiles.Length; i++)
            {
                try
                {
                    logFiles[i].Delete();
                }
                catch
                {
                    // Eski günlükleri silme başarısız olursa devam et
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Eski günlükleri temizlerken hata: {ex.Message}");
        }
    }
}
