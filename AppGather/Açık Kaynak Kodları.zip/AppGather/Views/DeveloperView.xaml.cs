﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class DeveloperView : System.Windows.Controls.UserControl
{
	public DeveloperView()
	{
		InitializeComponent();
		var items = DeveloperTweaksService.GetList();
		SecurityList.ItemsSource = new ObservableCollection<TweakItem>(items.Where(item => item.IsSecurityCritical));
		DeveloperList.ItemsSource = new ObservableCollection<TweakItem>(items.Where(item => !item.IsSecurityCritical));
		UpdateSelectionSummary(items);
	}

	private async void CreateRestorePoint_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			await RestorePointService.CreateAsync("Geliştirici menüsü öncesi geri yükleme noktası");
		}
		catch (System.Exception exception)
		{
			LogService.Log($"Geliştirici menüsü geri yükleme noktası hatası: {exception.Message}", "ERROR");
		}
	}

	private async void ApplySelected_Click(object sender, RoutedEventArgs e)
	{
		if (!AdminHelper.IsAdministrator())
		{
			MessageBox.Show("Bu geliştirici ayarları uygulamak için yönetici yetkisi gereklidir.", "Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
			return;
		}

		var allItems = new[]
		{
			SecurityList.ItemsSource as ObservableCollection<TweakItem>,
			DeveloperList.ItemsSource as ObservableCollection<TweakItem>
		}.Where(collection => collection is not null).SelectMany(collection => collection!).ToList();
		if (allItems.Count == 0)
		{
			return;
		}

		var selectedItems = allItems.Where(item => item.IsSelected).ToList();
		if (selectedItems.Count == 0)
		{
			MessageBox.Show("Uygulanacak geliştirici ayarı seçmediniz.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
			return;
		}

		if (selectedItems.Any(item => item.IsSecurityCritical))
		{
			var answer = MessageBox.Show(
				"Defender veya Windows Update seçildi. Bu işlem güvenlik güncellemelerini ve kötü amaçlı yazılım korumasını devre dışı bırakabilir. Devam etmek istediğinize emin misiniz?",
				"Kritik güvenlik uyarısı",
				MessageBoxButton.YesNo,
				MessageBoxImage.Warning);
			if (answer != MessageBoxResult.Yes)
			{
				return;
			}
		}

		if (!await RestorePointService.ConfirmAndCreateAsync("Geliştirici ayarları öncesi AppGather noktası"))
		{
			return;
		}

		foreach (var item in selectedItems)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(item.ApplyCommand))
				{
					var result = await PowerShellService.RunAsync(item.ApplyCommand);
					item.IsApplied = result.ExitCode == 0;
					LogService.Log($"Geliştirici ayar uygulandı: {item.Name}", result.ExitCode == 0 ? "SUCCESS" : "ERROR");
				}
			}
			catch (System.Exception exception)
			{
				LogService.Log($"Geliştirici ayar uygulama hatası: {item.Name}: {exception.Message}", "ERROR");
			}
		}

		UpdateSelectionSummary(new ObservableCollection<TweakItem>(allItems));
	}

	private void UpdateSelectionSummary(ObservableCollection<TweakItem> items)
	{
		var count = items.Count(item => item.IsSelected);
		SelectionSummaryText.Text = $"{count} öğe seçili";
	}
}
