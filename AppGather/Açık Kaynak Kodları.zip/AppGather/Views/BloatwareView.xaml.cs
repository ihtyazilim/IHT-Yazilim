﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class BloatwareView : System.Windows.Controls.UserControl
{
	private bool _isRemoving;

	public BloatwareView()
	{
		InitializeComponent();
		var items = BloatwareService.GetList();
		var groupedItems = new ListCollectionView(items);
		groupedItems.GroupDescriptions.Add(new PropertyGroupDescription(nameof(BloatwareItem.Category)));
		BloatwareList.ItemsSource = groupedItems;
		foreach (var item in items)
		{
			item.PropertyChanged += Item_PropertyChanged;
		}
		UpdateSelectionSummary(items);
	}

	private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (e.PropertyName == nameof(BloatwareItem.IsSelected) && BloatwareList.ItemsSource is ObservableCollection<BloatwareItem> items)
		{
			UpdateSelectionSummary(items);
		}
	}

	private void SelectAll_Click(object sender, RoutedEventArgs e)
	{
		if (BloatwareList.ItemsSource is ObservableCollection<BloatwareItem> items)
		{
			foreach (var item in items)
			{
				item.IsSelected = true;
			}

			UpdateSelectionSummary(items);
		}
	}

	private void ClearSelection_Click(object sender, RoutedEventArgs e)
	{
		if (BloatwareList.ItemsSource is ObservableCollection<BloatwareItem> items)
		{
			foreach (var item in items)
			{
				item.IsSelected = false;
			}

			UpdateSelectionSummary(items);
		}
	}

	private async void RemoveSelected_Click(object sender, RoutedEventArgs e)
	{
		if (_isRemoving)
		{
			return;
		}

		if (BloatwareList.ItemsSource is not ObservableCollection<BloatwareItem> items)
		{
			return;
		}

		var selectedItems = items.Where(item => item.IsSelected).ToList();
		if (selectedItems.Count == 0)
		{
			MessageBox.Show("Kaldırılacak öğe seçmediniz.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
			return;
		}

		_isRemoving = true;
		RemoveButton.IsEnabled = false;
		try
		{
			if (!await RestorePointService.ConfirmAndCreateAsync("Bloatware temizliği öncesi AppGather noktası"))
			{
				return;
			}

			foreach (var item in selectedItems)
			{
				try
				{
					if (await BloatwareService.RemoveAsync(item))
					{
						item.IsSelected = false;
					}
				}
				catch (System.Exception exception)
				{
					LogService.Log($"Bloatware kaldırma hatası: {exception.Message}", "ERROR");
				}
			}

			foreach (var item in selectedItems)
			{
				if (!item.IsSelected)
				{
					items.Remove(item);
				}
			}
		}
		finally
		{
			_isRemoving = false;
			RemoveButton.IsEnabled = true;
		}

		UpdateSelectionSummary(items);
	}

	private void UpdateSelectionSummary(ObservableCollection<BloatwareItem> items)
	{
		var count = items.Count(item => item.IsSelected);
		SelectionSummaryText.Text = $"{count} öğe seçili";
	}
}
