using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using AppGather.Services;

namespace AppGather.Views;

public partial class NetworkView : System.Windows.Controls.UserControl
{
    public NetworkView()
    {
        InitializeComponent();
    }

    private async void ApplyDns_Click(object sender, RoutedEventArgs e)
    {
        if (!AdminHelper.IsAdministrator())
        {
            MessageBox.Show("DNS ayarını değiştirmek için yönetici yetkisi gereklidir.", "Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        string[]? addresses = null;

        if (DnsProfileComboBox.SelectedItem is ComboBoxItem profileItem && profileItem.Tag is string profileName)
        {
            var selectedProfile = NetworkService.GetProfileByName(profileName);
            if (selectedProfile is not null)
            {
                addresses = selectedProfile.Addresses;
            }
        }

        // Custom DNS adresleri
        if (addresses is null || addresses.Length == 0)
        {
            addresses = new[] { PrimaryDnsTextBox.Text.Trim(), SecondaryDnsTextBox.Text.Trim() };
        }

        if (addresses.Any(address => !IPAddress.TryParse(address, out _)))
        {
            MessageBox.Show("Geçerli IPv4 veya IPv6 DNS adresleri girin.", "Geçersiz DNS", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!await RestorePointService.ConfirmAndCreateAsync("DNS değişikliği öncesi AppGather noktası"))
            return;

        var success = await NetworkService.ApplyDnsAsync(addresses);
        MessageBox.Show(success ? "DNS profili uygulandı." : "DNS profili uygulanamadı.", "DNS ayarı", MessageBoxButton.OK, success ? MessageBoxImage.Information : MessageBoxImage.Warning);
    }

    private async void TestConnection_Click(object sender, RoutedEventArgs e)
    {
        var result = await NetworkService.TestConnectionAsync();
        StatusText.Text = result.ExitCode == 0 && result.Output.Trim().Equals("True", StringComparison.OrdinalIgnoreCase)
            ? "Bağlantı başarılı."
            : "Bağlantı kurulamadı.";
    }

    private async void FlushDns_Click(object sender, RoutedEventArgs e)
    {
        if (!await RestorePointService.ConfirmAndCreateAsync("DNS temizliği öncesi AppGather noktası"))
        {
            return;
        }

        var success = await NetworkService.FlushDnsAsync();
        MessageBox.Show(success ? "DNS önbelleği temizlendi." : "DNS önbelleği temizlenemedi.", "Ağ işlemi", MessageBoxButton.OK, success ? MessageBoxImage.Information : MessageBoxImage.Warning);
    }

    private async void RenewIp_Click(object sender, RoutedEventArgs e)
    {
        if (!await RestorePointService.ConfirmAndCreateAsync("IP yenileme öncesi AppGather noktası"))
        {
            return;
        }

        var success = await NetworkService.RenewIpAsync();
        MessageBox.Show(success ? "IP adresi yenilendi." : "IP adresi yenilenemedi.", "Ağ işlemi", MessageBoxButton.OK, success ? MessageBoxImage.Information : MessageBoxImage.Warning);
    }
}
