﻿using System;
using System.Reflection;

namespace AppGather.Views;

public partial class AboutView : System.Windows.Controls.UserControl
{
	public AboutView()
	{
		InitializeComponent();
		var version = Assembly.GetExecutingAssembly().GetName().Version;
		VersionText.Text = $"Sürüm {version?.ToString(3) ?? "1.0.0"}";
	}
}
