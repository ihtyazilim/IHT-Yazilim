﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using System.Threading.Tasks;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class DashboardView : System.Windows.Controls.UserControl
{
	private readonly DispatcherTimer _processRefreshTimer = new() { Interval = TimeSpan.FromSeconds(3) };
	private bool _processRefreshInProgress;
	public DashboardView()
	{
		InitializeComponent();
		LoadSystemInfoSafely();
		_processRefreshTimer.Tick += (_, _) => RefreshProcesses();
		Loaded += (_, _) => RefreshProcesses();
		Unloaded += (_, _) => _processRefreshTimer.Stop();
	}

	private void LoadSystemInfoSafely()
	{
		try
		{
			var snapshot = SystemInfoService.GetSnapshot();
			OperatingSystemText.Text = snapshot.OperatingSystem;
			ArchitectureText.Text = snapshot.Architecture;
			MachineText.Text = snapshot.MachineName;
			UserText.Text = snapshot.UserName;
			AdminStatusText.Text = snapshot.AdminStatus;
			ProcessorText.Text = snapshot.Processor;
			MemoryText.Text = snapshot.Memory;
			SystemDriveText.Text = snapshot.SystemDrive;
			TemporaryFilesText.Text = snapshot.TemporaryFiles;
		}
		catch (Exception exception)
		{
			LogService.Log($"Sistem bilgileri okunamadı: {exception}", "WARN");
			OperatingSystemText.Text = "Doğrulanamıyor";
			ArchitectureText.Text = Environment.Is64BitOperatingSystem ? "64 bit" : "32 bit";
			MachineText.Text = Environment.MachineName;
			UserText.Text = Environment.UserName;
			AdminStatusText.Text = "Doğrulanamıyor";
			ProcessorText.Text = $"{Environment.ProcessorCount} mantıksal çekirdek";
			MemoryText.Text = "Doğrulanamıyor";
			SystemDriveText.Text = "Doğrulanamıyor";
			TemporaryFilesText.Text = "Doğrulanamıyor";
		}
	}

	private async void RefreshProcesses()
	{
		if (_processRefreshInProgress)
			return;

		_processRefreshInProgress = true;
		_processRefreshTimer.Stop();
		try
		{
			var snapshot = await Task.Run(() => (Processes: SystemInfoService.GetProcessSnapshot(), Temperatures: HardwareSensorService.GetTemperatures()));
			CpuProcessGrid.ItemsSource = snapshot.Processes.OrderByDescending(process => process.CpuPercent).ToList();
			MemoryProcessGrid.ItemsSource = snapshot.Processes.OrderByDescending(process => process.MemoryBytes).ToList();
			TemperatureList.ItemsSource = snapshot.Temperatures;
			TemperatureStatusText.Text = snapshot.Temperatures.Count == 0
				? "Bu bilgisayarda erişilebilir sıcaklık sensörü bulunamadı. Tahmini değer gösterilmiyor."
				: $"{snapshot.Temperatures.Count} gerçek sensör değeri okunuyor.";
			CpuSummaryText.Text = $"{snapshot.Processes.Count} süreç · Son 3 saniyelik CPU örneği";
			MemorySummaryText.Text = $"{snapshot.Processes.Count} süreç · Gerçek Working Set RAM değeri";
		}
		catch (Exception exception)
		{
			LogService.Log($"Süreç bilgileri okunamadı: {exception.Message}", "WARN");
			CpuSummaryText.Text = "CPU süreç bilgileri okunamadı";
			MemorySummaryText.Text = "RAM süreç bilgileri okunamadı";
		}
		finally
		{
			_processRefreshInProgress = false;
			if (IsLoaded)
				_processRefreshTimer.Start();
		}
	}

	private void RefreshProcesses_Click(object sender, RoutedEventArgs e) => RefreshProcesses();

	private async void CreateRestorePoint_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			var created = await RestorePointService.CreateAsync("AppGather güvenlik noktası");
			if (!created)
			{
				MessageBox.Show("Geri yükleme noktası oluşturulamadı. Lütfen yönetici yetkisini kontrol edin.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
			}
		}
		catch (Exception exception)
		{
			LogService.Log($"Geri yükleme noktası hatası: {exception.Message}", "ERROR");
			MessageBox.Show($"Geri yükleme noktası oluşturulurken hata oluştu:\n\n{exception.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}

	private async void CleanTemporaryFiles_Click(object sender, RoutedEventArgs e)
	{
		if (!await RestorePointService.ConfirmAndCreateAsync("Geçici dosya temizliği öncesi AppGather noktası"))
		{
			return;
		}

		try
		{
			var deleted = await CleanupService.CleanTemporaryFilesAsync();
			TemporaryFilesText.Text = "Temizlendi";
			MessageBox.Show($"Geçici dosya temizliği tamamlandı. {deleted} öğe işlendi.", "Temizlik tamamlandı", MessageBoxButton.OK, MessageBoxImage.Information);
		}
		catch (Exception exception)
		{
			LogService.Log($"Geçici dosya temizliği hatası: {exception.Message}", "ERROR");
			MessageBox.Show($"Temizlik sırasında hata oluştu:\n\n{exception.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}
}
