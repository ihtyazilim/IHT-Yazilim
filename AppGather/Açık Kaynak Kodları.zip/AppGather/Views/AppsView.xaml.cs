﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class AppsView : System.Windows.Controls.UserControl
{
	private bool _isInstalling;

	public AppsView()
	{
		InitializeComponent();
		var items = AppInstallService.GetList();
		AppList.ItemsSource = items;
		foreach (var item in items)
		{
			item.PropertyChanged += Item_PropertyChanged;
		}
		UpdateSelectionSummary(items);
	}

	private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (e.PropertyName == nameof(AppItem.IsSelected) && AppList.ItemsSource is ObservableCollection<AppItem> items)
		{
			UpdateSelectionSummary(items);
		}
	}

	private async void InstallSelected_Click(object sender, RoutedEventArgs e)
	{
		if (_isInstalling)
		{
			return;
		}

		if (AppList.ItemsSource is not ObservableCollection<AppItem> items)
		{
			return;
		}

		var selectedItems = items.Where(item => item.IsSelected).ToList();
		if (selectedItems.Count == 0)
		{
			MessageBox.Show("Kurulacak uygulama seçmediniz.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
			return;
		}

		_isInstalling = true;
		InstallButton.IsEnabled = false;
		try
		{
			if (!await RestorePointService.ConfirmAndCreateAsync("Uygulama kurulumu öncesi AppGather noktası"))
			{
				return;
			}

			foreach (var item in selectedItems)
			{
				try
				{
					await AppInstallService.InstallAsync(item);
				}
				catch (System.Exception exception)
				{
					LogService.Log($"Uygulama kurulumu hatası: {exception.Message}", "ERROR");
				}
			}
		}
		finally
		{
			_isInstalling = false;
			InstallButton.IsEnabled = true;
		}
	}

	private void UpdateSelectionSummary(ObservableCollection<AppItem> items)
	{
		var count = items.Count(item => item.IsSelected);
		SelectionSummaryText.Text = $"{count} öğe seçili";
	}
}
