﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class TweaksView : System.Windows.Controls.UserControl
{
	private bool _isStabilizing;
	public TweaksView()
	{
		InitializeComponent();
		var items = DeveloperTweaksService.GetList();
		TweakList.ItemsSource = items;
		UpdateSelectionSummary(items);
	}

	private async void ApplyStabilization_Click(object sender, RoutedEventArgs e)
	{
		if (_isStabilizing)
			return;

		if (!AdminHelper.IsAdministrator())
		{
			MessageBox.Show("Windows stabilizasyonu için yönetici yetkisi gereklidir.", "Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
			return;
		}

		var confirmation = MessageBox.Show(
			"Insider/Beta güncellemeleri, telemetri, reklam/öneriler ve Delivery Optimization eşler arası paylaşımı kapatılacak. Defender ve kararlı Windows Update açık kalacaktır. Devam edilsin mi?",
			"Windows Stabilizasyonu",
			MessageBoxButton.YesNo,
			MessageBoxImage.Warning);
		if (confirmation != MessageBoxResult.Yes)
			return;

		_isStabilizing = true;
		try
		{
			if (!await RestorePointService.ConfirmAndCreateAsync("Windows stabilizasyonu öncesi AppGather noktası"))
				return;

			var result = await WindowsStabilizationService.ApplyAsync();
			MessageBox.Show(result.Details, result.Success ? "Stabilizasyon tamamlandı" : "Stabilizasyon uyarısı", MessageBoxButton.OK, result.Success ? MessageBoxImage.Information : MessageBoxImage.Warning);
		}
		catch (System.Exception exception)
		{
			LogService.Log($"Windows stabilizasyonu hatası: {exception}", "ERROR");
			MessageBox.Show($"Stabilizasyon uygulanamadı:\n\n{exception.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
		}
		finally
		{
			_isStabilizing = false;
		}
	}

	private async void ApplySelected_Click(object sender, RoutedEventArgs e)
	{
		if (!AdminHelper.IsAdministrator())
		{
			MessageBox.Show("Bu ince ayarları uygulamak için yönetici yetkisi gereklidir.", "Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
			return;
		}

		if (TweakList.ItemsSource is not ObservableCollection<TweakItem> items)
		{
			return;
		}

		var selectedItems = items.Where(item => item.IsSelected).ToList();
		if (selectedItems.Count == 0)
		{
			MessageBox.Show("Uygulanacak ince ayar seçmediniz.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
			return;
		}

		if (!await RestorePointService.ConfirmAndCreateAsync("İnce ayar uygulaması öncesi AppGather noktası"))
		{
			return;
		}

		foreach (var item in selectedItems)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(item.ApplyCommand))
				{
					var result = await PowerShellService.RunAsync(item.ApplyCommand);
					item.IsApplied = result.ExitCode == 0;
					LogService.Log($"Ayar uygulandı: {item.Name}", result.ExitCode == 0 ? "SUCCESS" : "ERROR");
				}
			}
			catch (System.Exception exception)
			{
				LogService.Log($"Ayar uygulanamadı: {item.Name}: {exception.Message}", "ERROR");
			}
		}

		UpdateSelectionSummary(items);
	}

	private void UpdateSelectionSummary(ObservableCollection<TweakItem> items)
	{
		var count = items.Count(item => item.IsSelected);
		SelectionSummaryText.Text = $"{count} öğe seçili";
	}
}
