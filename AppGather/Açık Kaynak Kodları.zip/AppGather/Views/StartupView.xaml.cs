using System.Collections.ObjectModel;
using System.Windows;
using AppGather.Models;
using AppGather.Services;

namespace AppGather.Views;

public partial class StartupView : System.Windows.Controls.UserControl
{
    public StartupView()
    {
        InitializeComponent();
        StartupList.ItemsSource = StartupService.GetItems();
    }

    private async void RemoveSelected_Click(object sender, RoutedEventArgs e)
    {
        if (StartupList.SelectedItem is not StartupItem item)
        {
            MessageBox.Show("Kaldırılacak başlangıç girdisini seçin.", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (!await RestorePointService.ConfirmAndCreateAsync("Başlangıç girdisi değişikliği öncesi AppGather noktası"))
        {
            return;
        }

        if (StartupService.Remove(item) && StartupList.ItemsSource is ObservableCollection<StartupItem> items)
        {
            items.Remove(item);
        }
    }
}
