﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AppGather.Services;

namespace AppGather;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, FrameworkElement> _views = new(StringComparer.OrdinalIgnoreCase);

    public MainWindow()
    {
        try
        {
            InitializeComponent();

            _views["dashboard"] = DashboardViewControl;
            _views["bloatware"] = BloatwareViewControl;
            _views["apps"] = AppsViewControl;
            _views["tweaks"] = TweaksViewControl;
            _views["developer"] = DeveloperViewControl;
            _views["startup"] = StartupViewControl;
            _views["network"] = NetworkViewControl;
            _views["about"] = AboutViewControl;

            if (LogService.Entries != null)
            {
                LogItems.ItemsSource = LogService.Entries;
            }

            SetActiveView("dashboard");

            UpdateThemeButton();

            LogService.Log("Uygulama arayüzü hazır.", "INFO");
        }
        catch (Exception ex)
        {
            // Başlangıç hatasını App.OnStartup'a ilet; aksi halde pencere kısmen
            // oluşturulmuş halde kalabilir ve gerçek istisna debugger'dan gizlenir.
            LogService.Log($"Ana pencere oluşturulamadı: {ex}", "ERROR");
            throw;
        }
    }

    private void ThemeButton_Click(object sender, RoutedEventArgs e)
    {
        ThemeService.Toggle();
        UpdateThemeButton();
    }

    private void UpdateThemeButton()
    {
        ThemeButton.Content = ThemeService.IsLight ? "\uE706" : "\uE708";
        ThemeButton.ToolTip = ThemeService.IsLight ? "Koyu temaya geç" : "Açık temaya geç";
    }

    private void MenuList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (MenuList.SelectedItem is not ListBoxItem item)
        {
            return;
        }

        var tag = item.Tag?.ToString();
        if (string.IsNullOrWhiteSpace(tag))
        {
            return;
        }

        SetActiveView(tag);
    }

    private void ClearLog_Click(object sender, RoutedEventArgs e)
    {
        LogService.Clear();
    }

    private void SetActiveView(string tag)
    {
        foreach (var view in _views)
        {
            if (view.Value != null)
            {
                var isVisible = string.Equals(view.Key, tag, StringComparison.OrdinalIgnoreCase);
                view.Value.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        var pageTitles = new Dictionary<string, (string Title, string Subtitle)>
        {
            ["dashboard"] = ("Panel", "Sisteminizin durumunu izleyin"),
            ["bloatware"] = ("Bloatware", "Gereksiz yazılımları temizleyin"),
            ["apps"] = ("Uygulamalar", "Temiz ve güvenli araçları kurun"),
            ["tweaks"] = ("İnce Ayarlar", "Gizlilik ve performansı optimize edin"),
            ["developer"] = ("Geliştirici", "Tehlikeli ama güçlü ayarlar"),
            ["startup"] = ("Başlangıç", "Windows açılış uygulamalarını yönetin"),
            ["network"] = ("Ağ Araçları", "DNS, IP ve bağlantı araçları"),
            ["about"] = ("Hakkında", "Uygulama bilgileri ve lisans"),
        };

        if (pageTitles.TryGetValue(tag, out var pageInfo))
        {
            if (PageTitleText != null) PageTitleText.Text = pageInfo.Title;
            if (PageSubtitleText != null) PageSubtitleText.Text = pageInfo.Subtitle;
        }
    }
}