namespace AppGather.Models;

public sealed class ProcessInfoItem
{
    public int ProcessId { get; init; }
    public string Name { get; init; } = string.Empty;
    public string FilePath { get; init; } = string.Empty;
    public double CpuPercent { get; init; }
    public string CpuText => $"{CpuPercent:0.0}%";
    public long MemoryBytes { get; init; }
    public string MemoryText => FormatBytes(MemoryBytes);
    public string Status { get; init; } = string.Empty;

    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return $"{bytes:N0} B";
        double value = bytes;
        string[] units = ["KB", "MB", "GB", "TB"];
        var index = -1;
        while (value >= 1024 && index < units.Length - 1)
        {
            value /= 1024;
            index++;
        }

        return $"{value:0.##} {units[index]}";
    }
}
