﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AppGather.Models;

public partial class BloatwareItem : ObservableObject
{
    [ObservableProperty]
    private string _id = string.Empty;

    [ObservableProperty]
    private string _name = string.Empty;

    [ObservableProperty]
    private string _description = string.Empty;

    [ObservableProperty]
    private string _category = string.Empty;

    [ObservableProperty]
    private string _packageName = string.Empty;

    [ObservableProperty]
    private bool _isRecommended = true;

    [ObservableProperty]
    private bool _isSelected;
}
