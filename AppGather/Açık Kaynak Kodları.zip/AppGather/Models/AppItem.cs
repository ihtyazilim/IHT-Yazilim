﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AppGather.Models;

public partial class AppItem : ObservableObject
{
    [ObservableProperty]
    private string _id = string.Empty;

    [ObservableProperty]
    private string _name = string.Empty;

    [ObservableProperty]
    private string _category = string.Empty;

    [ObservableProperty]
    private string _wingetId = string.Empty;

    [ObservableProperty]
    private bool _isSelected;
}
