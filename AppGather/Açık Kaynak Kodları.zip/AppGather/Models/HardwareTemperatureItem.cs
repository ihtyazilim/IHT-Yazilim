namespace AppGather.Models;

public sealed class HardwareTemperatureItem
{
    public string Component { get; init; } = string.Empty;
    public string Sensor { get; init; } = string.Empty;
    public double ValueCelsius { get; init; }
    public string ValueText => $"{ValueCelsius:0.0} °C";
}