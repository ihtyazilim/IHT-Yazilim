﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AppGather.Models;

public partial class TweakItem : ObservableObject
{
    [ObservableProperty]
    private string _id = string.Empty;

    [ObservableProperty]
    private string _name = string.Empty;

    [ObservableProperty]
    private string _description = string.Empty;

    [ObservableProperty]
    private string _category = string.Empty;

    [ObservableProperty]
    private bool _isDangerous;

    [ObservableProperty]
    private bool _isSecurityCritical;

    [ObservableProperty]
    private bool _isDeveloper;

    [ObservableProperty]
    private string? _applyCommand;

    [ObservableProperty]
    private string? _revertCommand;

    [ObservableProperty]
    private bool _isSelected;

    [ObservableProperty]
    private bool _isApplied;
}
