namespace AppGather.Models;

public sealed class StartupItem
{
    public string Name { get; init; } = string.Empty;
    public string Command { get; init; } = string.Empty;
    public string Location { get; init; } = string.Empty;
    public string RegistryPath { get; init; } = string.Empty;
}
