﻿using System;

namespace AppGather.Models;

public class LogEntry
{
    public DateTime Timestamp { get; set; } = DateTime.Now;

    public string Level { get; set; } = "INFO";

    public string Message { get; set; } = string.Empty;

    public string FormattedLine => $"[{Timestamp:dd.MM.yyyy HH:mm:ss}] {Level}: {Message}";
}
