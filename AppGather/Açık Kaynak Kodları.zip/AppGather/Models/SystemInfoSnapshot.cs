namespace AppGather.Models;

public sealed class SystemInfoSnapshot
{
    public string OperatingSystem { get; init; } = string.Empty;
    public string Architecture { get; init; } = string.Empty;
    public string MachineName { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string AdminStatus { get; init; } = string.Empty;
    public string Processor { get; init; } = string.Empty;
    public string Memory { get; init; } = string.Empty;
    public string SystemDrive { get; init; } = string.Empty;
    public string TemporaryFiles { get; init; } = string.Empty;
}
