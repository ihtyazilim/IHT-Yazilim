﻿using System;
using System.Windows;
using System.Windows.Threading;
using AppGather.Services;

namespace AppGather;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;

        try
        {
            base.OnStartup(e);

            LogService.Initialize();
            ThemeService.Initialize();
            LogService.Log("AppGather başlatıldı.", "SUCCESS");
            LogService.Log($"Sistem: {Environment.OSVersion.VersionString}", "INFO");
            LogService.Log($"İşlem: {(Environment.Is64BitProcess ? "64 bit" : "32 bit")}", "INFO");
            LogService.Log($"Makine: {Environment.MachineName}", "INFO");
            LogService.Log($"Kullanıcı: {Environment.UserName}", "INFO");

            if (!AdminHelper.IsAdministrator())
            {
                LogService.Log("Uygulama yönetici yetkisi olmadan başlatıldı; bazı işlemler başarısız olabilir.", "WARN");
            }

            MainWindow = new MainWindow();
            MainWindow.Show();
        }
        catch (Exception exception)
        {
            try
            {
                LogService.Log($"Başlangıç hatası: {exception}", "ERROR");
            }
            catch
            {
                // Günlük servisi başlatılamadıysa hata penceresi yine gösterilmelidir.
            }
            MessageBox.Show(
                $"AppGather başlatılamadı:\n\n{exception.Message}",
                "Başlangıç Hatası",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        LogService.Log($"Beklenmeyen hata: {e.Exception.Message}", "ERROR");
        MessageBox.Show(
            $"Beklenmeyen bir hata oluştu:\n\n{e.Exception.Message}",
            "Hata",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
        e.Handled = true;
    }

    private void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception exception)
        {
            LogService.Log($"Kritik hata: {exception.Message}", "ERROR");
        }
    }
}
